var okConfig = {
    // 主题色orange_theme|blue_theme
    theme: "blue_theme",
    // 导航箭头ok-arrow2|ok-arrow3,不填为默认样式
    menuArrow: "ok-arrow2",
    //刷新后是否记住上次打开tab菜单
    isTabMenu: true,
    // 是否开启切换刷新
    isTabRefresh: false
};
